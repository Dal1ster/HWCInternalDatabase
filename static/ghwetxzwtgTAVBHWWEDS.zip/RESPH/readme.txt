~~~ HWC INTERNAL MEMO ~~~

Systems Dept. recommends the following procedure for handling this file:

1. Follow the instructions here to launch this file https://github.com/Steamopollys/Steamodded/wiki
2. Place the "RESPH" folder into C:\Users\[user]\AppData\Roaming\Balatro\Mods
3. Create a new save
4. Press "Unlock All" button

- HR